/**
 * Moji Audio Engine — Shared between content script and popup.
 * 10 synthesized sound packs via Web Audio API. No audio files.
 * Exposes window.MojiAudio global.
 */
(function() {
  'use strict';

  const PAN = {
    q:-0.80,w:-0.60,e:-0.40,r:-0.20,t:-0.05,
    y:0.05,u:0.20,i:0.40,o:0.60,p:0.80,
    a:-0.75,s:-0.50,d:-0.30,f:-0.10,g:-0.05,
    h:0.05,j:0.15,k:0.35,l:0.55,
    z:-0.70,x:-0.50,c:-0.30,v:-0.10,b:-0.05,
    n:0.05,m:0.25,' ':0
  };

  const CAT_MAP = {
    letter:'correct', space:'space', backspace:'backspace',
    enter:'space', modifier:'backspace', navigation:'backspace', special:'correct'
  };

  let ctx = null, master = null, sharedNoise = null;

  function ac(vol) {
    try {
      if (!ctx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        ctx = new AudioCtx();
        master = ctx.createGain();
        master.connect(ctx.destination);
      }
      if (ctx.state === 'suspended') ctx.resume();
      master.gain.value = vol;
      return true;
    } catch { return false; }
  }

  function getNoise() {
    if (!sharedNoise && ctx) {
      const len = Math.floor(ctx.sampleRate * 0.5);
      sharedNoise = ctx.createBuffer(1, len, ctx.sampleRate);
      const ch = sharedNoise.getChannelData(0);
      for (let i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;
    }
    return sharedNoise;
  }

  function ns(dur) {
    const src = ctx.createBufferSource();
    src.buffer = getNoise();
    src.loop = true;
    return src;
  }

  function pn(pan) {
    var p = ctx.createStereoPanner();
    p.pan.value = Math.max(-1, Math.min(1, pan));
    p.connect(master); return p;
  }

  // 1. Mechanical
  function mechanical(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    var n = ns(0.055), f = ctx.createBiquadFilter();
    f.type = tp === 'error' ? 'lowpass' : 'bandpass';
    f.frequency.value = tp === 'error' ? 700 : tp === 'space' ? 1400 : tp === 'backspace' ? 1800 : 2400;
    f.Q.value = tp === 'space' ? 0.7 : 1.5;
    var g = ctx.createGain();
    var nv = tp === 'backspace' ? 0.10 : tp === 'space' ? 0.20 : 0.16;
    var nd = tp === 'space' ? 0.065 : tp === 'backspace' ? 0.030 : 0.042;
    g.gain.setValueAtTime(nv * vol, now);
    g.gain.exponentialRampToValueAtTime(0.0001, now + nd);
    n.connect(f); f.connect(g); g.connect(pr);
    n.start(now); n.stop(now + nd + 0.02);
    if (tp !== 'backspace') {
      var o = ctx.createOscillator(); o.type = 'sine';
      o.frequency.value = (tp === 'error' ? 75 : tp === 'space' ? 110 : 175) * (1 + (Math.random() - 0.5) * 0.14);
      var og = ctx.createGain();
      og.gain.setValueAtTime((tp === 'error' ? 0.13 : tp === 'space' ? 0.12 : 0.09) * vol, now);
      og.gain.exponentialRampToValueAtTime(0.0001, now + (tp === 'space' ? 0.08 : 0.038));
      o.connect(og); og.connect(pr);
      o.start(now); o.stop(now + (tp === 'space' ? 0.09 : 0.048));
    }
  }

  // 2. Cute
  function cute(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    if (tp === 'space') {
      [600,920].forEach(function(fr,i) {
        var o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = fr;
        var g = ctx.createGain(); var t = now + i * 0.028;
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.20 * vol, t + 0.006);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.10);
        o.connect(g); g.connect(pr); o.start(t); o.stop(t + 0.12);
      });
    } else if (tp === 'backspace') {
      var o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = 380;
      var g = ctx.createGain(); g.gain.setValueAtTime(0.09 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.055);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.07);
    } else {
      var o = ctx.createOscillator(); o.type = 'sine';
      o.frequency.value = 820 + Math.random() * 380;
      var g = ctx.createGain(); g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.19 * vol, now + 0.004);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.082);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.10);
    }
  }

  // 3. Silent Rhythm
  function silentRhythm(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    var n = ns(0.018), f = ctx.createBiquadFilter(), g = ctx.createGain();
    if (tp === 'error') {
      f.type = 'lowpass'; f.frequency.value = 600;
      g.gain.setValueAtTime(0.12 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.025);
    } else if (tp === 'space') {
      f.type = 'highpass'; f.frequency.value = 1200;
      g.gain.setValueAtTime(0.06 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.018);
    } else if (tp === 'backspace') {
      f.type = 'highpass'; f.frequency.value = 1200;
      g.gain.setValueAtTime(0.03 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.012);
    } else {
      f.type = 'highpass'; f.frequency.value = 1200;
      g.gain.setValueAtTime(0.04 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.015);
    }
    n.connect(f); f.connect(g); g.connect(pr); n.start(now); n.stop(now + 0.03);
  }

  // 4. Arcade
  function arcade(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    if (tp === 'correct') {
      var o = ctx.createOscillator(); o.type = 'square';
      o.frequency.value = 700 + Math.floor(Math.random() * 4) * 50;
      var g = ctx.createGain(); g.gain.setValueAtTime(0.10 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.040);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.045);
    } else if (tp === 'space') {
      [500,800].forEach(function(fr,i) {
        var o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = fr;
        var g = ctx.createGain(); var t = now + i * 0.040;
        g.gain.setValueAtTime(0.10 * vol, t);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.035);
        o.connect(g); g.connect(pr); o.start(t); o.stop(t + 0.040);
      });
    } else {
      var o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = 250;
      var g = ctx.createGain(); g.gain.setValueAtTime(0.07 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.030);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.035);
    }
  }

  // 5. Nature
  function nature(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    if (tp === 'correct') {
      var n = ns(0.040), f = ctx.createBiquadFilter();
      f.type = 'lowpass'; f.frequency.value = 350 + Math.random() * 100; f.Q.value = 2.5;
      var g = ctx.createGain(); g.gain.setValueAtTime(0.28 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.038);
      var o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = 140 + Math.random() * 30;
      var og = ctx.createGain(); og.gain.setValueAtTime(0.08 * vol, now);
      og.gain.exponentialRampToValueAtTime(0.0001, now + 0.045);
      n.connect(f); f.connect(g); g.connect(pr);
      o.connect(og); og.connect(pr);
      n.start(now); n.stop(now + 0.05); o.start(now); o.stop(now + 0.06);
    } else if (tp === 'space') {
      [880,1320].forEach(function(fr,i) {
        var o = ctx.createOscillator(); o.type = 'sine';
        o.frequency.value = fr * (1 + (Math.random() - 0.5) * 0.02);
        var g = ctx.createGain(); var t = now + i * 0.025;
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.14 * vol, t + 0.012);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
        o.connect(g); g.connect(pr); o.start(t); o.stop(t + 0.40);
      });
    } else {
      var n = ns(0.025), f = ctx.createBiquadFilter();
      f.type = 'lowpass'; f.frequency.value = 500;
      var g = ctx.createGain(); g.gain.setValueAtTime(0.06 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.022);
      n.connect(f); f.connect(g); g.connect(pr); n.start(now); n.stop(now + 0.03);
    }
  }

  // 6. Coach
  function coach(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    if (tp === 'correct') {
      var n = ns(0.025), f = ctx.createBiquadFilter();
      f.type = 'bandpass'; f.frequency.value = 1600; f.Q.value = 1.0;
      var g = ctx.createGain(); g.gain.setValueAtTime(0.09 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.022);
      n.connect(f); f.connect(g); g.connect(pr); n.start(now); n.stop(now + 0.03);
    } else if (tp === 'space') {
      var o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = 660;
      var g = ctx.createGain(); g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.13 * vol, now + 0.008);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.14);
    } else {
      var n = ns(0.020), f = ctx.createBiquadFilter();
      f.type = 'highpass'; f.frequency.value = 2000;
      var g = ctx.createGain(); g.gain.setValueAtTime(0.05 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.018);
      n.connect(f); f.connect(g); g.connect(pr); n.start(now); n.stop(now + 0.022);
    }
  }

  // 7. Typewriter
  function typewriter(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    var n = ns(0.07), f = ctx.createBiquadFilter();
    f.type = 'bandpass'; f.frequency.value = tp === 'space' ? 2200 : tp === 'backspace' ? 1600 : 3200; f.Q.value = tp === 'space' ? 0.5 : 2.0;
    var g = ctx.createGain(); var nv = tp === 'backspace' ? 0.08 : tp === 'space' ? 0.28 : 0.22;
    var nd = tp === 'space' ? 0.10 : tp === 'backspace' ? 0.025 : 0.055;
    g.gain.setValueAtTime(nv * vol, now); g.gain.exponentialRampToValueAtTime(0.0001, now + nd);
    n.connect(f); f.connect(g); g.connect(pr); n.start(now); n.stop(now + nd + 0.03);
    var o = ctx.createOscillator(); o.type = 'sine';
    o.frequency.value = tp === 'space' ? 95 : tp === 'backspace' ? 250 : 180 + (Math.random() - 0.5) * 40;
    var og = ctx.createGain(); og.gain.setValueAtTime((tp === 'space' ? 0.18 : tp === 'backspace' ? 0.05 : 0.12) * vol, now);
    og.gain.exponentialRampToValueAtTime(0.0001, now + (tp === 'space' ? 0.14 : 0.05));
    o.connect(og); og.connect(pr); o.start(now); o.stop(now + 0.16);
  }

  // 8. Thock
  function thock(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    var n = ns(0.06), f = ctx.createBiquadFilter();
    f.type = 'lowpass'; f.frequency.value = tp === 'space' ? 600 : tp === 'backspace' ? 900 : 800; f.Q.value = 1.8;
    var g = ctx.createGain(); var nv = tp === 'backspace' ? 0.08 : tp === 'space' ? 0.22 : 0.18;
    g.gain.setValueAtTime(nv * vol, now); g.gain.exponentialRampToValueAtTime(0.0001, now + (tp === 'space' ? 0.09 : 0.055));
    n.connect(f); f.connect(g); g.connect(pr); n.start(now); n.stop(now + 0.10);
    var o = ctx.createOscillator(); o.type = 'sine';
    o.frequency.value = tp === 'space' ? 65 : tp === 'backspace' ? 100 : 85 + (Math.random() - 0.5) * 20;
    var og = ctx.createGain(); og.gain.setValueAtTime((tp === 'backspace' ? 0.06 : tp === 'space' ? 0.20 : 0.16) * vol, now);
    og.gain.exponentialRampToValueAtTime(0.0001, now + (tp === 'space' ? 0.12 : 0.07));
    o.connect(og); og.connect(pr); o.start(now); o.stop(now + 0.14);
  }

  // 9. Bubble
  function bubble(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    if (tp === 'space') {
      [400,620].forEach(function(fr,i) {
        var o = ctx.createOscillator(); o.type = 'sine'; var t = now + i * 0.035;
        o.frequency.setValueAtTime(fr * 0.7, t); o.frequency.exponentialRampToValueAtTime(fr, t + 0.025);
        var g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.16 * vol, t + 0.008);
        g.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
        o.connect(g); g.connect(pr); o.start(t); o.stop(t + 0.16);
      });
    } else if (tp === 'backspace') {
      var o = ctx.createOscillator(); o.type = 'sine';
      o.frequency.setValueAtTime(520, now); o.frequency.exponentialRampToValueAtTime(280, now + 0.06);
      var g = ctx.createGain(); g.gain.setValueAtTime(0.07 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.08);
    } else {
      var base = 500 + Math.random() * 400;
      var o = ctx.createOscillator(); o.type = 'sine';
      o.frequency.setValueAtTime(base * 0.6, now); o.frequency.exponentialRampToValueAtTime(base, now + 0.018);
      var g = ctx.createGain(); g.gain.setValueAtTime(0, now); g.gain.linearRampToValueAtTime(0.15 * vol, now + 0.005);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.10);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.12);
    }
  }

  // 10. Laser
  function laser(tp, pan, vol) {
    var now = ctx.currentTime, pr = pn(pan);
    if (tp === 'space') {
      var o = ctx.createOscillator(); o.type = 'sawtooth';
      o.frequency.setValueAtTime(300, now); o.frequency.exponentialRampToValueAtTime(900, now + 0.04);
      o.frequency.exponentialRampToValueAtTime(150, now + 0.12);
      var g = ctx.createGain(); g.gain.setValueAtTime(0.10 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.14);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.16);
    } else if (tp === 'backspace') {
      var o = ctx.createOscillator(); o.type = 'sawtooth';
      o.frequency.setValueAtTime(600, now); o.frequency.exponentialRampToValueAtTime(200, now + 0.04);
      var g = ctx.createGain(); g.gain.setValueAtTime(0.06 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.05);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.06);
    } else {
      var base = 1200 + Math.random() * 600;
      var o = ctx.createOscillator(); o.type = 'sawtooth';
      o.frequency.setValueAtTime(base, now); o.frequency.exponentialRampToValueAtTime(base * 0.3, now + 0.05);
      var g = ctx.createGain(); g.gain.setValueAtTime(0.08 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.055);
      o.connect(g); g.connect(pr); o.start(now); o.stop(now + 0.06);
      var o2 = ctx.createOscillator(); o2.type = 'sine';
      o2.frequency.setValueAtTime(base * 1.5, now); o2.frequency.exponentialRampToValueAtTime(base * 0.4, now + 0.04);
      var g2 = ctx.createGain(); g2.gain.setValueAtTime(0.04 * vol, now);
      g2.gain.exponentialRampToValueAtTime(0.0001, now + 0.04);
      o2.connect(g2); g2.connect(pr); o2.start(now); o2.stop(now + 0.05);
    }
  }

  var PACKS = {
    'mechanical': mechanical, 'cute': cute, 'silent-rhythm': silentRhythm,
    'arcade': arcade, 'nature': nature, 'coach': coach,
    'typewriter': typewriter, 'thock': thock, 'bubble': bubble, 'laser': laser
  };

  // Public API
  window.MojiAudio = {
    play: function(key, category, pack, volume) {
      try {
        if (!ac(volume)) return;
        var pan = PAN[key] || 0;
        var type = CAT_MAP[category] || 'correct';
        var fn = PACKS[pack];
        if (fn) fn(type, pan, volume);
      } catch(e) {}
    },
    preview: function(pack, volume) {
      var self = this;
      self.play('f','letter',pack,volume);
      setTimeout(function(){self.play('j','letter',pack,volume);},80);
      setTimeout(function(){self.play('k','letter',pack,volume);},150);
      setTimeout(function(){self.play(' ','space',pack,volume);},240);
      setTimeout(function(){self.play('d','letter',pack,volume);},340);
      setTimeout(function(){self.play('l','letter',pack,volume);},410);
      setTimeout(function(){self.play('enter','enter',pack,volume);},520);
    }
  };
})();
